To run the Compiler, run the JackAnalyzer.py with one argument, the file/folder containing the Jack files

python LincolnBennettProject10/JackAnalyzer.py LincolnBennettProject10/10/Square

Test files from Nand2Tetris have been included in the zip file. 

After running JackAnalyzer.py, the program will create a new output folder and create a .xml file with the same name as the .jack file it is translating. 

Note that the program includes the "halfway" translated file (example MainT.xml).
